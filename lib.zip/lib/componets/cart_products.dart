import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class cart_products extends StatefulWidget {
  @override
  _cart_productsState createState() => _cart_productsState();
}

class _cart_productsState extends State<cart_products> {
  var Product_on_the_cart = [
    {
      "name": "blazzer",
      "price": "85",
      "picture": "images/products/blazer1.jpeg",
      "quantity": "1",
      "size":"M",
      "color":"red",
    },
    {
      "name": "dress",
      "price": "85",
      "picture": "images/products/dress1.jpeg",
      "quantity": "1",
      "size":"M",
      "color":"red",
    },

  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: Product_on_the_cart.length,
        itemBuilder: (context, index) {
          return single_cart_product(
            cart_prodname: Product_on_the_cart[index]["name"],
            cart_prodprice: Product_on_the_cart[index]["price"],
            cart_prodimg: Product_on_the_cart[index]["picture"],
            cart_quantity: Product_on_the_cart[index]["quantity"],
            cart_color: Product_on_the_cart[index]["color"],
            cart_size: Product_on_the_cart[index]["size"],
          );
        });
  }
}

class single_cart_product extends StatelessWidget {
  final String cart_prodname, cart_prodprice, cart_prodimg, cart_quantity,cart_color,cart_size;

  single_cart_product(
      {this.cart_prodname,
        this.cart_prodprice,
        this.cart_prodimg,
        this.cart_quantity,
      this.cart_color,
      this.cart_size
      });

  @override
  Widget build(BuildContext context) {
    return Card(

      child: ListTile(

        leading: Image.asset(
          cart_prodimg,
          height:150.0,
          width: 80.0,
        ),
        title: Text(cart_prodname),
        subtitle: Column(
          children: [
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(0.0),
                  child: Expanded(child: Text('size')),
                ),
                Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Text(cart_size,style: TextStyle(color: Colors.red),),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20.0, 8.0, 8.0, 8.0),
                  child: Expanded(child: Text('color')),
                ),
                Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Text(cart_color,style: TextStyle(color: Colors.red)),
                ),

              ],
            ),
            Container(
              alignment: Alignment.topLeft,
              child: Text("\$${cart_prodprice}",
                style: TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ),
            
          ],

        ),
        trailing: new Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[

            IconButton(
              padding:EdgeInsets.all(0.0),
              iconSize: 15,
              icon: Icon(Icons.arrow_drop_up),
              onPressed: () {},

            ),

            IconButton(

              padding:EdgeInsets.all(0.0),
              iconSize: 15,
              icon: Icon(Icons.arrow_drop_down),
              onPressed: () {},
            )
          ],
        ),

      ),
    );
  }
}
