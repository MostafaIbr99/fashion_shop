import 'package:flutter/material.dart';
import 'package:fashion_shop/componets/cart_products.dart';
import 'package:fashion_shop/componets/horizontal_listview.dart';
class cart extends StatefulWidget {
  @override
  _cartState createState() => _cartState();
}

class _cartState extends State<cart> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        elevation: 0.1,
        backgroundColor: Colors.red.shade900,
        title: Text('Fashshop'),
        actions: <Widget>[
          new IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.white,
              ),
              onPressed: () {}),
          new IconButton(
              icon: Icon(
                Icons.shopping_cart,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=>cart()),);
              })
        ],
      ),

      body: cart_products(),
      bottomNavigationBar: new Container(
        color: Colors.white,
        child: Row(
          children: [
            Expanded(
                child: ListTile(
                  title: Text('total price:'),
                  subtitle: Text('\$200'),
                )),
            Expanded(
                child: MaterialButton(
                  onPressed: () {},
                  child: Text(
                    "check out",
                    style: TextStyle(color: Colors.white),
                  ),
                  color: Colors.red,
                ))
          ],
        ),
      ),
    );
  }
}
