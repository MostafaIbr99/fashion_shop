import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class productdetails extends StatefulWidget {
  final product_details_name;
  final product_details_picture;
  final product_details_old_price;
  final product_details_new_price;

  productdetails({
    this.product_details_name,
    this.product_details_picture,
    this.product_details_old_price,
    this.product_details_new_price,
  });

  @override
  _productdetailsState createState() => _productdetailsState();
}

class _productdetailsState extends State<productdetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        elevation: 0.1,
        backgroundColor: Colors.red.shade900,
        title: Text('Fashshop'),
        actions: <Widget>[
          new IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.white,
              ),
              onPressed: () {}),
          new IconButton(
              icon: Icon(
                Icons.shopping_cart,
                color: Colors.white,
              ),
              onPressed: () {})
        ],
      ),
      body: new ListView(
        children: <Widget>[
          new Container(
            height: 300,
            child: GridTile(
              child: Container(
                color: Colors.white,
                child: Image.asset(widget.product_details_picture),
              ),
              footer: new Container(
                color: Colors.white70,
                child: ListTile(
                  leading: new Text(
                    widget.product_details_name,
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0),
                  ),
                  title: new Row(
                    children: <Widget>[
                      Expanded(
                          child: new Text(
                        "\$${widget.product_details_old_price}",
                        style: TextStyle(
                            color: Colors.grey,
                            decoration: TextDecoration.lineThrough),
                      )),
                      Expanded(
                          child: new Text(
                        "\$${widget.product_details_new_price}",
                        style: TextStyle(
                            color: Colors.red, fontWeight: FontWeight.bold),
                      )),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Row(
            children: <Widget>[
              Expanded(
                  child: MaterialButton(
                    onPressed: () {
                      showDialog(context: context,
                          builder: (context){
                        return new AlertDialog(
                          title: Text('size'),
                          content: Text('choose the size'),
                          actions: <Widget>[
                            new MaterialButton(
                                onPressed: ()=>Navigator.of(context).pop(context),
                              child: Text('close'),
                            )
                          ],
                        );
                          },
                      );
                    },
                    color: Colors.white,
                    textColor: Colors.grey,
                    elevation: 0.2,
                    child: Row(
                      children: [
                        Expanded(child: new Text('size')),
                        Expanded(child: Icon(Icons.arrow_drop_down))
                      ],
                    ),
                  )),
              Expanded(
                  child: MaterialButton(
                    onPressed: () {
                      showDialog(context: context,
                        builder: (context){
                          return new AlertDialog(
                            title: Text('color'),
                            content: Text('choose the color'),
                            actions: <Widget>[
                              new MaterialButton(
                                onPressed: ()=>Navigator.of(context).pop(context),
                                child: Text('close'),
                              )
                            ],
                          );
                        },
                      );
                    },
                    color: Colors.white,
                    textColor: Colors.grey,
                    elevation: 0.2,
                    child: Row(
                      children: [
                        Expanded(child: new Text('color')),
                        Expanded(child: Icon(Icons.arrow_drop_down))
                      ],
                    ),
                  )),
              Expanded(
                  child: MaterialButton(
                    onPressed: () {
                      showDialog(context: context,
                        builder: (context){
                          return new AlertDialog(
                            title: Text('quantity'),
                            content: Text('choose the quantity'),
                            actions: <Widget>[
                              new MaterialButton(
                                onPressed: ()=>Navigator.of(context).pop(context),
                                child: Text('close'),
                              )
                            ],
                          );
                        },
                      );
                    },
                    color: Colors.white,
                    textColor: Colors.grey,
                    elevation: 0.2,
                    child: Row(
                      children: [
                        Expanded(child: new Text('qty')),
                        Expanded(child: Icon(Icons.arrow_drop_down))
                      ],
                    ),
                  ))
            ],
          ),
          Row(
            children: <Widget>[
              Expanded(
                  child: MaterialButton(
                    onPressed: () {},
                    color: Colors.red,
                    textColor: Colors.white,
                    elevation: 0.2,
                    child: new Text('add to cart'),
                  )),
              new IconButton(icon: Icon(Icons.add_shopping_cart,color: Colors.red,), onPressed: (){}),
              new IconButton(icon: Icon(Icons.favorite_border,color: Colors.red,), onPressed: (){})

            ],
          ),
          Divider(),
          new ListTile(
            title: Text('product details'),
            subtitle: Text("This book is for developers. You should be familiar with any object-oriented programming language: if you understand variables, functions, classes, and objects, this book is for you. The programming language used in Flutter is Dart. If you've never seen Dart before, don't worry: basic knowledge of languages like Java, C#, Kotlin, Swift, or JavaScript will be enough to follow along with the projects in this book. Dart is an extremely intuitive language for developers, with a smooth learning curve."),
          ),
          Divider(),
          Row(
            children: [
              Padding(padding: const EdgeInsets.fromLTRB(12, 5, 5, 5),
                child: Text("product name",style: TextStyle(color: Colors.grey),),
              ),
              Padding(padding: EdgeInsets.all(5),
              child: Text(widget.product_details_name),
              ),

            ],
          ),
          Row(
            children: [
              Padding(padding: const EdgeInsets.fromLTRB(12, 5, 5, 5),
                child: Text("product brand",style: TextStyle(color: Colors.grey),),
              ),
              Padding(padding: EdgeInsets.all(5),
                child: Text("brand x"),
              ),

            ],
          ),
          Row(
            children: [
              Padding(padding: const EdgeInsets.fromLTRB(12, 5, 5, 5),
                child: Text("product condition",style: TextStyle(color: Colors.grey),),
              ),
              Padding(padding: EdgeInsets.all(5),
                child: Text("NEW"),
              ),




            ],
          ),
          Divider(),
          Text('similar products',style: TextStyle(fontWeight: FontWeight.bold),),
          Divider(),
          Container(
            height: 360.0,
            child: similer_product(),
          ),
        ],
        
      ),
    );
  }
}
class similer_product extends StatefulWidget {
  @override
  _similer_productState createState() => _similer_productState();
}

class _similer_productState extends State<similer_product> {
  var product_list = [
    {
      "name": "Blazer",
      "picture": "images/products/blazer1.jpeg",
      "old_price": 120,
      "price": 85,
    },


    {
      "name": "Red dress",
      "picture": "images/products/hills1.jpeg",
      "old_price": 100,
      "price": 50,
    },



    {
      "name": "Red dress",
      "picture": "images/products/dress2.jpeg",
      "old_price": 100,
      "price": 50,
    },




  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: product_list.length,
        gridDelegate:
        new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemBuilder: (BuildContext context, int index) {
          return Similer_single_prod(
            prod_name: product_list[index]['name'],
            prod_pricture: product_list[index]['picture'],
            prod_old_price: product_list[index]['old_price'],
            prod_price: product_list[index]['price'],
          )
          ;
        });
  }
}

class Similer_single_prod extends StatelessWidget {
  final prod_name;
  final prod_pricture;
  final prod_old_price;
  final prod_price;

  Similer_single_prod({
    this.prod_name,
    this.prod_pricture,
    this.prod_old_price,
    this.prod_price,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Hero(
          tag: Text('hero1'),
          child: Material(
            child: InkWell(
              onTap: ()=>Navigator.of(context).push(
                  MaterialPageRoute(builder: (context)=>new productdetails(
                    product_details_name:prod_name ,
                    product_details_new_price:prod_price ,
                    product_details_old_price:prod_old_price ,
                    product_details_picture: prod_pricture,
                  )
                  )),
              child: GridTile(
                  footer: Container(
                    color: Colors.white70,
                    child: ListTile(
                      leading: Text(
                        prod_name,
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      title: Text(
                        "\$$prod_price",
                        style: TextStyle(
                            color: Colors.red, fontWeight: FontWeight.w800),
                      ),
                      subtitle: Text(
                        "\$$prod_old_price",
                        style: TextStyle(
                            color: Colors.black54,
                            fontWeight: FontWeight.w800,
                            decoration
                                :TextDecoration.lineThrough),
                      ),
                    ),
                  ),
                  child: Image.asset(
                    prod_pricture,
                    fit: BoxFit.cover,
                  )),
            ),
          )),
    );
  }
}

